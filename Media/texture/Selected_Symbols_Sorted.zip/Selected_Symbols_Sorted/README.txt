2 folders
has_beat & not_has_beat
which 你懂的

has_beat contains: 2(half), 4(quarter), 8(eighth), 16(sixteenth), 32(...)

data.csv

column 1: file names
column 2: whether it has beat: 0 for false & 1 for true
column 3: 所占节拍 

** Special symbol: musical_symbol_combining_augmentation_dot (附点)，单独处理（mark it as -1 in column 3）

If you have any problem, for free to contact me. Thanks. 

Jinjie