这里的 png 都是剪裁过的，我这里还有原始尺寸的，背景透明的，invert 过的


json file 包括

name: name of file (category)
x: center x
y: center y
w: width
h: hight

如果需要其他格式的文档或者数据用来做 bounding ，我这里可以生成。Thanks！